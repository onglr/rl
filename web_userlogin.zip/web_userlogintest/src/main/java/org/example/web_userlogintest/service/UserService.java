package org.example.web_userlogintest.service;

import org.example.web_userlogintest.pojo.User;

//用户服务的接口类
public interface UserService {
    //登录
    User login(User user1);
}
