package org.example.web_userlogintest.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {
}
