package org.example.web_userlogintest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebUserlogintestApplication {

    public static void main(String[] args) {

        SpringApplication.run(WebUserlogintestApplication.class, args);


    }

}
